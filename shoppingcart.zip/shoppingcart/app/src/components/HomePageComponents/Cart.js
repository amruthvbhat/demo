import { Button, Card, CardActionArea, CardActions, CardContent, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import CartService from '../../service/CartService'
import ProductComponent from './ProductComponent'

const Cart = () => {
    const [items,setItems]=useState([])
    const history = useNavigate();
    useEffect(()=>{
        getCartItems();
    },[])
    const getCartItems=()=>{
        if(sessionStorage.getItem('id'))
        {
            CartService.getCartItems(sessionStorage.getItem('id')).then((response)=>{
                setItems(response.data)
                console.log(response.data);
            }).catch(error => {
                console.log(error);
            })
        }
        else
        {
            alert('Login to continue')
            history('/login')
        }
    }
  return (
    <div>
        <div>
        <ProductComponent/>
        </div>
        <div className='row'>
        {items.map(
            item=>(
                <Card sx={{ maxWidth: 600, marginLeft:12,marginTop:10}}>
                <CardActionArea>
                    <CardContent>
                        <Typography gutterBottom variant="h4" component="div">
                           Product : {item.productName}
                        </Typography>
                        <Typography variant="body5" color="text.secondary">
                            Price : {item.price}
                        </Typography><br/>
                        <Typography variant="body5" color="text.secondary">
                            Quantity : {item.quantity}
                        </Typography>
                    </CardContent>
                </CardActionArea>
                <CardActions>
                <Button size="small" >Delete</Button>
                </CardActions>
            </Card>
            )
        )}
    </div></div>
  );
}

export default Cart