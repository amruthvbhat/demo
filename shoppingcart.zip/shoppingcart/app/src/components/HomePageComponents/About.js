import { Box, Container, createTheme, CssBaseline, Link, ThemeProvider, Typography } from '@mui/material'
import React from 'react'
import ProductComponent from './ProductComponent'
import FacebookIcon from '@mui/icons-material/Facebook';
const darkTheme = createTheme({
  palette: {
    mode: 'dark',
  },
});

const social={ name: 'Facebook', icon: FacebookIcon };
function Copyright() {
  return (
    <Typography variant="body2" color="text.secondary">
      {'Copyright © '}
      <Link color="inherit" href="https://localhost:3000">
        Shopping Cart
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}

const About = () => {
  return (
    <ThemeProvider theme={darkTheme}>
    <div>
        <div>
        <ProductComponent/>
        </div>
        <div>
            
            
        <CssBaseline />
      
    

        <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        minHeight: '100vh',
      }}
    >
      <CssBaseline />
      <Container component="main" sx={{ mt: 8, mb: 2 }} maxWidth="sm" >
        <Typography variant="h2" component="h1" gutterBottom>
          About us..
        </Typography>
        <Typography variant="h5" component="h2" gutterBottom>
          {''}</Typography>
          <Typography variant="h5" component="h2" gutterBottom>
          {'A website to satisfy all your shopping needs'}
        </Typography>
        <Typography variant="body1">ADDRESS:</Typography>
        <Typography variant="body1">City:   Bangalore</Typography>
        <Typography variant="body1">State/province/area:    Karnataka</Typography>

        <Typography variant="body1">Phone number  11981051798</Typography>

        <Typography variant="body1">Zip code  110027</Typography>
      </Container>
      <Box
        component="footer"
        sx={{
          py: 3,
          px: 2,
          mt: 'auto',
          backgroundColor: (theme) =>
            theme.palette.mode === 'light'
              ? theme.palette.grey[200]
              : theme.palette.grey[800],
        }}
      >
        <Container maxWidth="sm">
          <Typography variant="body1">
            For frequent questions, contact us.
          </Typography>
          <Copyright />
        </Container>
      </Box>
    </Box>
        </div>
    </div>
    </ThemeProvider>
  )
}

export default About