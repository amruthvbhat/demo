import { Button, Card, CardActionArea, CardActions, CardContent, CardMedia, createTheme, ThemeProvider, Typography } from '@mui/material'
import React, { useState } from 'react'
import ProductComponent from './ProductComponent';
import 'bootstrap/dist/css/bootstrap.css';
import { Link } from 'react-router-dom';

const Home = () => {
    const [category, setCategory] = useState([{name:'Electronics',image:"https://image.shutterstock.com/image-photo/electronic-gadgets-on-black-concrete-260nw-1628963260.jpg",description:"electronic products online at best prices now! Buy tablets, mobile phones, mobile accessories, televisions, smart watches, laptop & accessories"}, 
    {name:'Fashion',image:"https://image.shutterstock.com/image-photo/flat-lay-womens-items-sneakers-260nw-1050931484.jpg",description:" style, clothing, and the clothing industry (and related trends) cultural and social trends generally."},{name: 'Grocery',image:"https://149366112.v2.pressablecdn.com/wp-content/uploads/2015/02/bulk-food.jpg",description:"Buy grocery and more from brands such as Kellogg's, Tata Gold, Parle G, Lays, etc. Order the online grocery comfortably from home for timely "},{ name:'Appliances',image:"https://www.homestratosphere.com/wp-content/uploads/2018/12/All-types-of-appliances-in-appliance-store-dec5.jpg",description:"Online shopping for Home and Kitchen Appliances Offers from a great selection at Home & Kitchen Store."},{name:'Furniture',image:"https://www.ulcdn.net/media/furniture-stores/bangalore/hsr-bda/HSR-store-737x413px.jpg?1657792551",description:"Buy Wooden Furniture Online at India's Largest Online Furniture Store at the guaranteed lowest price in India."}]);
    return (
        <div>
            <div>
                <ProductComponent  />
            </div>
            <div className='row' >
                {  
                    category.map(i => (
                        <Card sx={{ maxWidth: 600, marginLeft:12,marginTop:10}}>
                            <CardActionArea>
                                <CardMedia
                                    component="img"
                                    height="270"
                                    image={i.image}
                                    alt={i.name}
                                />
                                <CardContent>
                                    <Typography gutterBottom variant="h4" component="div">
                                        {i.name}
                                    </Typography>
                                    <Typography variant="body5" color="text.secondary">
                                        {i.description}
                                    </Typography>
                                </CardContent>

                            </CardActionArea>
                            <CardActions>
                            <Link className="btn" to={`/products/${i.name}`} >View Product</Link>
                            </CardActions>
                        </Card>
                    ))
                }
            </div>
        </div>
    );
}

export default Home