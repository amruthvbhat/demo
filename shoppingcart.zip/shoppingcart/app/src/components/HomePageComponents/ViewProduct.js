import { Button, IconButton, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import ProductService from '../../service/ProductService';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import ProductComponent from './ProductComponent'
import CartService from '../../service/CartService';

const ViewProduct = () => {
  const {id} = useParams();
  const [itemId,setItemId]=useState('')
  const [productType,setProductType]=useState('')
  const [productName,setProductName]=useState('')
  const [productRating,setProductRating]=useState('')
  const [productReview,setProductReview]=useState('')
  const [productImage,setProductImage]=useState('')
  const [price,setPrice]=useState('')
  const [productDescription,setProductDescription]=useState('')
  const [productSpecification,setProductSpecification]=useState('')
  const [productCategory,setProductCategory]=useState('')
  const [quantity,setQuantity]=useState('')
  const history = useNavigate();
  useEffect(()=>{
    getAllProducts();
},{})
const getAllProducts =()=>{
    ProductService.getProductbyid(id).then((response)=>{
        setItemId(response.data.productId)
        setProductName(response.data.productName)
        setProductCategory(response.data.category)
        setProductDescription(response.data.description)
        setProductImage(response.data.image[0])
        setPrice(response.data.price)
        setProductRating(response.data.rating["1"])
        setProductReview(response.data.review["1"])
        setProductSpecification(response.data.specification.a)
        setProductType(response.data.productType)
        console.log(response.data);
    }).catch(error => {
        console.log(error);
    })
}
const addToCart = (e) =>{
  const item={itemId,productName,price,quantity}
  e.preventDefault();
  console.log(item)
  CartService.updateCart(sessionStorage.getItem('id'),item).then((response) =>{
      alert('Added to Cart')
      console.log(response.data)

      history('/cart');

  }).catch(error => {
      alert('Error in adding to Cart'+item.itemId+item.productName+item.price+item.quantity)
      console.log(error)
  })
}
const addQuantity=(q)=>{
  q=q+1;
  setQuantity(q)
}
const removeQuantity=(q)=>{
  if(q<=0)
  {
    q=0;
  }
  else{
  q=q-1;}
  setQuantity(q)
}
const deleteProduct=(itemId)=>{
  CartService.deleteIte(sessionStorage.getItem('id'),itemId).then((response)=>{
    console.log(response.data)
  })
  alert('Product deleted')
  history('/cart');
}


  return (
    <div style={{ height: 400, width: '100%' }}>
      <div>
        <ProductComponent/>
      </div>
      <div>{sessionStorage.getItem('id')}</div>
      <div style={{ display: 'flex', height: '100%' }}>
        <img src={productImage}></img></div>
        <div style={{ flexGrow: 1 }}>
        <Typography gutterBottom variant="h5" component="div">Name : {productName}<br/></Typography>
        <Typography gutterBottom variant="h5" component="div">Type : {productType}<br/></Typography>
        <Typography gutterBottom variant="h5" component="div">Price : {price}<br/></Typography>
        <Typography gutterBottom variant="h5" component="div">Description : {productDescription}<br/></Typography>
        <Typography gutterBottom variant="h5" component="div">Category : {productCategory}<br/></Typography>
        <Typography gutterBottom variant="h5" component="div">Specification : {productSpecification}<br/></Typography>
        <Typography gutterBottom variant="h5" component="div">Rating :{productRating}<br/></Typography>
        <Typography gutterBottom variant="h5" component="div">Review :{productReview}<br/></Typography>
        <Typography gutterBottom variant="h5" component="div">
        Quantity :<br/>
        <IconButton size="large"edge="start"color="inherit"aria-label="open drawer" onClick={()=>addQuantity(quantity)}>
          <AddIcon/>
        </IconButton>{quantity}
        <IconButton size="large"edge="start"color="inherit"aria-label="open drawer" onClick={()=>removeQuantity(quantity)}>
          <RemoveIcon/>
        </IconButton>
        <br/></Typography>
        <button onClick={(e)=>addToCart(e)} >Add To Cart</button>
        <Button href='/cart' size="large" color="primary" onClick={(e) =>{addToCart(e);}} sx={{flex:1}} >Add To Cart</Button>
        <button onClick={(e)=>DeleteFromCart(e)} >Delete From Cart</button>
        <Button href='/cart' size="large" color="primary" onClick={(e) =>{deleteProduct(e);}} sx={{flex:1}} >Delete From Cart</Button>
        
      </div>

    </div> 
  )
  
}

export default ViewProduct