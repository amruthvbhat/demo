import React from 'react'
import SignIn from '../SignIn'
import ProductComponent from './ProductComponent'

const Login = () => {
  return (
    <div>
        <div>
        <ProductComponent/>
        </div>
        <div>
            <SignIn/>
        </div>
    </div>
  )
}

export default Login