import { Typography } from '@mui/material'
import React from 'react'
import ProductComponent from './ProductComponent'
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

const Contact = () => {
  return (
    <div>
        <div>
        <ProductComponent/>
        </div>
        <Typography variant="h2" component="h1" gutterBottom>
          Frequently Asked questions
        </Typography>
        <div classname ="container">
        <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header">
          <Typography>Orders</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Accordion>
          <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header">
          <Typography>I missed the delivery of my order today. What should I do?</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Typography>
          The courier service delivering your order usually tries to deliver on the next business day in case you miss a delivery.

          You can check your SMS for more details on when the courier service will try to deliver again.
          </Typography>
          </AccordionDetails>
          </Accordion>
          <Accordion>
          <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header">
          <Typography>Will the delivery be tried again if I'm not able to collect my order the first time?</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Typography>
          Couriers make sure that the delivery is re-attempted the next working day if you can't collect your order the first time.
          </Typography>
          </AccordionDetails>
          </Accordion>
          <Accordion>
          <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header">
          <Typography>The delivery of my order is delayed. What should I do?</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Typography>
          On the rare occasion that your order is delayed, please check your email & messages for updates. A new delivery timeframe will be shared with you and you can also track its status by visiting My Orders.
          </Typography>
          </AccordionDetails>
          </Accordion>
          </AccordionDetails>
        </Accordion>
      



        <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header">
          <Typography>Cancellations and Returns</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Accordion>
          <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header">
          <Typography>If I request for a replacement, when will I get it?</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Typography>
          Visit My Orders to check the status of your replacement.

          In most locations, the replacement item is delivered to you at the time of pick-up. In all other areas, the replacement is initiated after the originally delivered item is picked up. Please check the SMS & email we send you for your replacement request for more details.
          </Typography>
          </AccordionDetails>
          </Accordion>
          <Accordion>
          <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header">
          <Typography>How do returns work?</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Typography>
          Once you raise a request, you'll get an email and SMS confirming that your request is being processed. Based on the item, your request may be automatically approved or you may be contacted for more details. If the request is approved, the item will be picked up after which you will get a replacement or refund.
          </Typography>
          </AccordionDetails>
          </Accordion>
          <Accordion>
          <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header">
          <Typography>Do I have to return the freebie when I return a product?</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Typography>
          Yes, the freebie has to be returned along with the product.
          </Typography>
          </AccordionDetails>
          </Accordion>
          </AccordionDetails>
        </Accordion>




        <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header">
          <Typography>Shopping</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Accordion>
          <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header">
          <Typography>Why do I see different prices for the same product?</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Typography>
          You could see different prices for the same product, as it could be listed by many Sellers.
          </Typography>
          </AccordionDetails>
          </Accordion>
          <Accordion>
          <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header">
          <Typography>Is installation offered for all products?</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Typography>
          Installation and demo are offered for certain items by sellers through the brand or an authorised service provider. Please check the individual product page to see if these services are offered for the item.
          </Typography>
          </AccordionDetails>
          </Accordion>
          <Accordion>
          <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header">
          <Typography>The delivery of my order is delayed. What should I do?</Typography>
          </AccordionSummary>
          <AccordionDetails>
          <Typography>
          On the rare occasion that your order is delayed, please check your email & messages for updates. A new delivery timeframe will be shared with you and you can also track its status by visiting My Orders.
          </Typography>
          </AccordionDetails>
          </Accordion>
          </AccordionDetails>
        </Accordion>



        <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography>Want to reach us old style ? Here is ourpostal address</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          <Typography variant="body1">ADDRESS:</Typography>
        <Typography variant="body1">City:   Bangalore</Typography>
        <Typography variant="body1">State/province/area:    Karnataka</Typography>

        <Typography variant="body1">Phone number  11981051798</Typography>

        <Typography variant="body1">Zip code  110027</Typography>
          </Typography>
        </AccordionDetails>
      </Accordion>
        </div>
    </div>
  );
}

export default Contact