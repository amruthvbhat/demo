import { Button, Card, CardActionArea, CardActions, CardContent, CardMedia, IconButton, InputBase, Rating, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom';
import SearchIcon from '@mui/icons-material/Search';
import ProductService from '../../service/ProductService';
import ProductComponent from './ProductComponent';
import UserProfile from '../UserProfile';

const Products = () => {
    const [products,setProducts]= useState([])
    const [pname,setPname]=useState('');
    const {productType} = useParams();
    useEffect(()=>{
        getAllProducts();
    },[])
    const searchProduct = (e) =>{
        
        ProductService.getProductByType(pname).then((response)=>{
            setProducts(response.data)
            console.log(response.data);
        }).catch(error => {
            console.log(error);
        })
    }
    const getAllProducts =()=>{
        if(productType != null)
        {
            ProductService.getProductByType(productType).then((response)=>{
                setProducts(response.data)
                console.log(response.data);
            }).catch(error => {
                console.log(error);
            })
        }
        else
        {
            ProductService.getallproducts().then((response)=>{
                setProducts(response.data)
                console.log(response.data);
            }).catch(error => {
                console.log(error);
            })
        }
    }
    
  return (
    <div>
    <div><ProductComponent/></div>
    <div>{sessionStorage.getItem('id')}</div>
    <div><InputBase sx={{ml:1,flex:1}} 
    type="text" 
    placeholder='Enter Product'
    value={pname}
    onChange={(e)=>setPname(e.target.value)} ></InputBase>
        <IconButton type="button" sx={{p:'10px'}} arial-label="search" onClick={(e)=>searchProduct(e)}>
       <SearchIcon/> </IconButton></div>

    <div className='row'>
        {
            products.map(item=>
                <Card sx={{ maxWidth: 345, marginLeft:2,marginTop:1}}>
                <CardActionArea>
                    <CardMedia
                        component="img"
                        height="140"
                        image={item.image.at(0)}
                        alt={item.productName}
                        
                    />
                    <CardContent>
                       
                        <Typography gutterBottom variant="h5" component="div">
                        {item.productName}
                        </Typography>
                        <Typography gutterBottom variant="h5" component="div">
                        Rs.{item.price}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                        {item.description}
                        </Typography>
                        <Rating name="read-only" value={item.rating[1]} readOnly ></Rating>
                    </CardContent>
                </CardActionArea>
                <CardActions>
                    <Link className="btn btn-info" to={`/viewProducts/${item.productId}`}  >View Product</Link>
                </CardActions>
            </Card>
            )
        }
    </div>
    <div>
    </div>
    </div>
  );
}

export default Products