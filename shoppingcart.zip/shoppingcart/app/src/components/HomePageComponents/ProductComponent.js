import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import ShoppingCartCheckoutIcon from '@mui/icons-material/ShoppingCartCheckout';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { AppBar, Box, Button,  IconButton, Rating, Toolbar } from '@mui/material'
import React, { useState } from 'react'

const ProductComponent = () => {
  return (
      <div><>
      <Box sx={{flexGrow:1}}>
        <AppBar position='static'>
          <Toolbar>
            <IconButton 
            href='/home'
            size="large"
            edge="start"
            color="inherit"
            aria-label="open drawer"
            sx={{ mr: 2 }}>
              <ShoppingCartIcon/>
              Shoping Cart
            </IconButton>
            <Button variant='text'
            href='/home'
            size="large"
            edge="start"
            color="inherit"
            aria-label="open drawer"
            sx={{flex:1}}>Home</Button>
            <Button href='/products' variant='text'size="large"
            edge="start"
            color="inherit"
            aria-label="open drawer"
            sx={{ flex:1}}>Product</Button>
            <Button href='/about' variant='text'size="large"
            edge="start"
            color="inherit"
            aria-label="open drawer"
            sx={{ flex:1}}>About</Button>
            <Button href='/contact' variant='text'size="large"
            edge="end"
            color="inherit"
            aria-label="open drawer"
            sx={{ flex:1 }}>Contact</Button>
            <IconButton 
            href='/cart'
            size="large"
            edge="start"
            color="inherit"
            aria-label="open drawer"
            sx={{ flex:1 }}>
            <ShoppingCartCheckoutIcon/>
            </IconButton>
            <IconButton 
            href='/login'
            size="large"
            edge="start"
            color="inherit"
            aria-label="open drawer"
            sx={{ flex:1 }}>
            <AccountCircleIcon/>
            </IconButton>
            
          </Toolbar>
        </AppBar>
      </Box>
      </>
</div>
  )
}

export default ProductComponent