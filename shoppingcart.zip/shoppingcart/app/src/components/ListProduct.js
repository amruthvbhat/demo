
import React,{useState,useEffect} from 'react'
import ProductService from '../service/ProductService'


const ListProduct=()=> {
    const [products,setProducts]= useState([])
    useEffect(()=>{
        getAllProducts();
    },[])
    const getAllProducts =()=>{
        ProductService.getallproducts().then((response)=>{
            setProducts(response.data)
            console.log(response.data);
        }).catch(error => {
            console.log(error);
        })
    }
    return (
        <div className='container'>
        
        <h2 className = "text-center"> products </h2>
        <table className='table table-bordered table-striped'>
            <thead class="thead-dark">
                <th>productId   </th>
                <th>productType     </th>
                <th>productName     </th>
                <th>Category        </th>
                <th>price       </th>
                <th>description     </th>

            </thead>
            <tbody>
                {
                    products.map(
                        products =>
                        <tr key ={products.productId}>
                            <td>{products.productId}</td><br></br>
                            <td>{products.productType}</td>
                            <td>{products.productName}</td>
                            <td>{products.Category}</td>
                            <td>{products.price}</td>
                            <td>{products.description}</td>

                        </tr>
                    )
                }
            </tbody>
        </table>
    </div>
    );
}

export default ListProduct