var UserProfile = (function(){
    var userId =0;
    var getUserId = function()
    {
        return userId;
    }
    var setUserId = function(user_userId)
    {
        userId = user_userId;
    }
    return{
        getUserId: getUserId,
        setUserId: setUserId
    }
})();

export default UserProfile;