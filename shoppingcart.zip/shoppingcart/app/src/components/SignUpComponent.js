import { Button, Link } from '@mui/material'
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import ProfileService from '../service/ProfileService'

const SignUpComponent = () => {

    const [profileId, setProfileId] = useState('')
    const [fullName, setFullName] = useState('')
    const [emailId, setEmailid] = useState('')
    const [mobileNumber, setMobileNumber] = useState('')
    const [about, setAbout] = useState('')
    const [dateOfBirth, setDateOfBirth] = useState('')
    const [gender, setGender] = useState('')
    const [role, setRole] = useState('')
    const [password, setPassword] = useState('')
    const history = useNavigate();

    const saveUser= (e) => {
        e.preventDefault();

        const userProfile = {profileId, fullName, emailId, mobileNumber, about, dateOfBirth, gender, role, password}
        console.log(userProfile)
        ProfileService.addNewCustomerProfile(userProfile).then((response) =>{

            alert('Successful sign up')
            console.log(response.data)

            history('/login');

        }).catch(error => {
            alert('Error in sign'+error)
            console.log(error)
        })
    }

  return (
    <div>
        <br /><br />

           <div className = "container">
            
                <div className = "row">
                <h2 className = "text-center">Register</h2>
                    <div className = "card col-md-6 offset-md-3 offset-md-3">
                    
                        <div className = "card-body">
                            <form>

                            <div className = "form-group mb-2">
                                    <label className = "form-label"> ID :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter id"
                                        name = "id"
                                        className = "form-control"
                                        value = {profileId}
                                        onChange = {(e) => setProfileId(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Full Name :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter full name"
                                        name = "fullName"
                                        className = "form-control"
                                        value = {fullName}
                                        onChange = {(e) => setFullName(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Email :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter mailid"
                                        name = "emailId"
                                        className = "form-control"
                                        value = {emailId}
                                        onChange = {(e) => setEmailid(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Mobile Number :</label>
                                    <input
                                        type = "number"
                                        placeholder = "Enter mobile number "
                                        name = "mobileNumber"
                                        className = "form-control"
                                        value = {mobileNumber}
                                        onChange = {(e) => setMobileNumber(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label"> About :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter about "
                                        name = "about"
                                        className = "form-control"
                                        value = {about}
                                        onChange = {(e) => setAbout(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Date Of Birth :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter date of birth "
                                        name = "dateOfBirth"
                                        className = "form-control"
                                        value = {dateOfBirth}
                                        onChange = {(e) => setDateOfBirth(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Gender :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter gender "
                                        name = "gender"
                                        className = "form-control"
                                        value = {gender}
                                        onChange = {(e) => setGender(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Role :</label>
                                    <input
                                        type = "text"
                                        placeholder = "Enter role "
                                        name = "role"
                                        className = "form-control"
                                        value = {role}
                                        onChange = {(e) => setRole(e.target.value)}
                                    >
                                    </input>
                                </div>

                                <div className = "form-group mb-2">
                                    <label className = "form-label"> Password :</label>
                                    <input
                                        type = "password"
                                        placeholder = "Enter password "
                                        name = "password"
                                        className = "form-control"
                                        value = {password}
                                        onChange = {(e) => setPassword(e.target.value)}
                                    >
                                    </input>
                                </div>

                                
                                <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
              onClick={(e)=>saveUser(e)}
            >
              submit
            </Button>
                                <div className="text-center">Already have an account?<Button href='/login' size="small"
            edge="start"
            
            aria-label="open drawer"
            sx={{ flex:1}}>Sign in</Button></div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
    </div>
  )
}

export default SignUpComponent