import './App.css';
import {
  BrowserRouter as Router,Route,Routes
} from 'react-router-dom';
import ListProduct from './components/ListProduct';
import Orders from './components/Orders';
import ProductComponent from './components/HomePageComponents/ProductComponent';
import Products from './components/HomePageComponents/Products';
import Home from './components/HomePageComponents/Home';
import Login from './components/HomePageComponents/Login';
import Contact from './components/HomePageComponents/Contact';
import About from './components/HomePageComponents/About';
import Cart from './components/HomePageComponents/Cart';
import ViewProduct  from './components/HomePageComponents/ViewProduct';
import SignUpComponent from './components/SignUpComponent';






function App() {
  return (
    <Router>
       <Routes>
        

        <Route path='/' element={<ListProduct/>}> </Route>
        <Route path='/order' element={<Orders/>}> </Route>
        <Route path='/home' element={<Home/>}></Route>
        <Route path='/login' element={<Login/>}></Route>
        <Route path='/signup' element={<SignUpComponent/>}></Route>

        <Route path='/contact' element={<Contact/>}></Route>
        <Route path='/about' element={<About/>}></Route>
        <Route path='/cart' element={<Cart/>}></Route>
        <Route path='/products' element={<Products/>}></Route>
        <Route path='/products/:productType' element={<Products/>}></Route>
        <Route path='/viewProducts/:id' element={<ViewProduct/>}></Route>
        <Route path='/productsmenu' element={<ProductComponent/>}></Route>

      </Routes>     
    </Router>
  );
}

export default App;
