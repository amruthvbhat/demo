import axios from 'axios'
const profile_url='http://localhost:8080/profile';
class ProfileService{
    getProfilebyid(profileId)
    {
        return axios.get(profile_url+'/getid/'+profileId)
    }
    addNewCustomerProfile(userProfile)
    {
        return axios.post(profile_url+'/customerProfile',userProfile)
    }
}
export default new ProfileService();