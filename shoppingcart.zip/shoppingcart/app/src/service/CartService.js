import axios from "axios";

const cart_url='http://localhost:8080/cart';

class CartService{
    getallcarts()
    {
        return axios.get(cart_url+'/getall');

    }

    getCartbyid()
    {
        return axios.get(cart_url+'/get')
    }

    getCartItems(cartId)
    {
        return axios.get(cart_url+'/'+cartId+'/items')
    }
    updateCart(id,item)
    {
        return axios.put(cart_url+'/update/'+id,item)
    }
}
export default new CartService();