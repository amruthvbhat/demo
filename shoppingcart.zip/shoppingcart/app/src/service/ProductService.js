import axios from 'axios'
const product_url='http://localhost:8080/product';

class ProductService{
    getallproducts()
    {
        return axios.get(product_url+'/getall');

    }
    getProductByType(productType)
    {
        return axios.get(product_url+'/getproducttype/'+productType)
    }

    getProductbyid(productId)
    {
        return axios.get(product_url+'/getid/'+productId)
    }
    getProductByName(productName)
    {
        return axios.get(product_url+'/getname/'+productName)
    }
}
export default new ProductService();