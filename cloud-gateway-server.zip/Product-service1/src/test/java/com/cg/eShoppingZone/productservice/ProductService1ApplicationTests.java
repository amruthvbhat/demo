package com.cg.eShoppingZone.productservice;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.inOrder;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.OngoingStubbing;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.unitils.reflectionassert.ReflectionAssert;


import com.capgemini.productservice.entity.Product;
import com.capgemini.productservice.repository.ProductRepository;
import com.capgemini.productservice.service.ProductServiceImpl;

@ExtendWith(MockitoExtension.class)
@DisplayName("Testing CartServiceImpl")
class ProductService1ApplicationTests {
	@InjectMocks
	ProductServiceImpl productService;
	
	@Mock
	ProductRepository productRepository;
	
	@BeforeEach
	void init_mocks() {
		MockitoAnnotations.openMocks(this);
	}


	@Nested
	@DisplayName("add product")
	class addProduct_Method{
		
		@Test
		public void addProduct1()
		{
			Product product= new Product(10,"fruit","apple","food", null, null, null, 20.00, "healthy food ", null);
			productService.addProduct(product);
			InOrder inOrder = Mockito.inOrder(productRepository);
			inOrder.verify(productRepository,times(1)).save(any(Product.class));
		}
		
		@Test
		public void addProduct2()
		{
			Product product= new Product(10,"fruit","apple","food", null, null, null, 20.00, "healthy food ", null);
			productService.addProduct(product);
			productRepository.save(product);
			
		
		}
	}
	
	@Nested
	@DisplayName("get All Products")
	class getAllProducts_Method{
		
		@Test
		public void getAllProducts1()
		{
			productService.getAllProducts();
			InOrder inorder=inOrder(productRepository);
			inorder.verify(productRepository,times(1)).findAll();
		}
		
		@Test
		public void getAllProducts2()
		{
			Product product1= new Product(10,"fruit","apple","food", null, null, null, 20.00, "healthy food ", null);
			Product product2= new Product(11,"fruit","apple","food", null, null, null, 20.00, "healthy food ", null);
			List<Product> products= new ArrayList<Product>();
			products.add(product1);
			products.add(product2);
			when(productRepository.findAll()).thenReturn(products);
			//productService.addProduct(product1);
			assertEquals(2, productService.getAllProducts().size());
			
		}
	}
	
	
	@Nested
	@DisplayName("getProductByName")
	class getProductByName_Method{
		
		@Test
		public void getProductByName1()
		{
			
			productService.getProductByName("apple");
			InOrder inOrder=Mockito.inOrder(productRepository);
			inOrder.verify(productRepository,times(1)).findByProductName("apple");
			
		}
		@Test
		public void getProductByName2()
		{
			Product product1= new Product(10,"fruit","apple","food", null, null, null, 20.00, "healthy food ", null);
			Product product2= new Product(10,"fruit","orange","food", null, null, null, 30.00, "healthy food ", null);
			//List<Product> products=new ArrayList<>();
			//products.add(product1);
			//products.add(product2);
			//when(productRepository.findByProductName("apple").isPresent());
			
		}
		
	
	}
	
	@Nested
	@DisplayName("deleteProductById")
	class deleteProductById_Method{
		@Test
		void deleteProductById1()
		{
			productService.deleteProductById(10);
			InOrder inOrder=Mockito.inOrder(productRepository);
			inOrder.verify(productRepository,times(1)).deleteById(10);
		}
		
		@Test
		void deleteProductById2()
		{
			Product product1= new Product(10,"fruit","apple","food", null, null, null, 20.00, "healthy food ", null);
			productRepository.deleteById(10);
			InOrder inorder=inOrder(productRepository);
			inorder.verify(productRepository,times(0)).save(product1);
			inorder.verify(productRepository,times(1)).deleteById(10);
		}
		
	}
	
	@Nested
	@DisplayName("updateProducts")
	class updateProducts_Method
	{
		@Test
		void updateProducts1()
		{
			Product product1= new Product(10,"fruit","apple","food", null, null, null, 20.00, "healthy food ", null);
			productRepository.save(product1);
			InOrder inorder=inOrder(productRepository);
			inorder.verify(productRepository,times(1)).save(product1);
		}
		
		@Test
		void updateProducts2()
		{
			
			Product product= new Product(10,"fruit","apple","food", null, null, null, 20.00, "healthy food ", null);
			Product newproduct= new Product();
			newproduct.setCategory(product.getCategory());
			newproduct.setDescription(product.getDescription());
			newproduct.setImage(product.getImage());
			newproduct.setPrice(product.getPrice());
			newproduct.setProductId(product.getProductId());
			newproduct.setProductName(product.getProductName());
			newproduct.setProductType(product.getProductType());
			newproduct.setRating(product.getRating());
			newproduct.setReview(product.getReview());
			newproduct.setSpecification(product.getSpecification());
			
			productRepository.save(newproduct);
			ReflectionAssert.assertReflectionEquals(product, newproduct);
			InOrder inorder=inOrder(productRepository);
			inorder.verify(productRepository,times(1)).save(newproduct);
			
		}
	}
		
	@Nested
	@DisplayName("getProductByCategory")
	class getProductByCategory_Method
	{
			
		@Test
		void getProductByCategory1()
		{
			productService.getProductByCategory("food");
			InOrder inOrder=Mockito.inOrder(productRepository);
			inOrder.verify(productRepository,times(1)).findByCategory("food");
		}
			
		@Test
		void getProductByCategory2()
		{
			Product product= new Product(10,"fruit","apple","food", null, null, null, 20.00, "healthy food ", null);
			List<Product> products= new ArrayList<Product>();
			products.add(product);
			when(productRepository.findByCategory("food")).thenReturn(products);
			productService.getProductByCategory("food");
			
			
		}
	}
	
	@Nested
	@DisplayName("getProductByType")
	class getProductByType_Method
	{
			
		@Test
		void getProductByType1()
		{
			productService.getProductByType("fruit");
			InOrder inOrder=Mockito.inOrder(productRepository);
			inOrder.verify(productRepository,times(1)).findByProductType("fruit");
		}
		
		@Test
		void getProductByType2()
		{
			Product product= new Product(10,"fruit","apple","food", null, null, null, 20.00, "healthy food ", null);
			List<Product> products= new ArrayList<Product>();
			products.add(product);
			when(productRepository.findByProductType("fruit")).thenReturn(products);
			productService.getProductByType("fruit");
		}
	}
		
		
	
	
}
	
	
		
	
	


