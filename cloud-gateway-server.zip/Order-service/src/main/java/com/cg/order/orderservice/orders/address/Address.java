package com.cg.order.orderservice.orders.address;

import java.time.LocalDate;

import org.springframework.data.annotation.Id;

import com.cg.order.orderservice.orders.Orders;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Address {
	@Id
	private Integer customerId;
	private String fullName;
	private String mobileNumber;
	private Integer flatNumber;
	private String city;
	private Integer pincode;
	private String state;
	

}
