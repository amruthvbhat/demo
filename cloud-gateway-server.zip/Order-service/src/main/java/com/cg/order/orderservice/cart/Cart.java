package com.cg.order.orderservice.cart;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data 
@AllArgsConstructor 
@NoArgsConstructor 
@Getter
@Setter
public class Cart {

	@Id
	@Field
	private int cartId;
	
	@Field
	private double totalPrice;
	
	@Field
	private List<Items> listOfItems;
	
	@Field
	private int itemId;
	
	
	

}



	