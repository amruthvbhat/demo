package com.cg.order.orderservice.orders.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cg.order.orderservice.cart.Cart;
import com.cg.order.orderservice.orders.Orders;
import com.cg.order.orderservice.orders.address.Address;

@Service
public interface OrderService {

	List<Orders> getAllOrders();

	void placeOrder(Cart cart);

	void onlinePayment(Cart cart);

	String changeStatus(String orderStatus, int orderId);

	void deleteOrder(int orderId);

	List<Orders> getOrderByCustomerId(int orderId);

	

	List<Address> getAddressByCustomerId(int customerId);

	List<Address> getAllAddress();


	Optional<Orders> getOrderById(int orderId);

	void storeAddress(Address address, int orderId);

	Orders getOrderById(Integer orderId);

}
