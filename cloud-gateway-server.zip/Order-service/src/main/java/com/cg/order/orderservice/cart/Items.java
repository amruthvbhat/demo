package com.cg.order.orderservice.cart;

import org.springframework.data.mongodb.core.mapping.Document;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@ToString
@Data
@AllArgsConstructor 
@NoArgsConstructor 
public class Items {
	private int itemId;
	private String productName;
	private double price;
	private int quantity;
		
	
}
