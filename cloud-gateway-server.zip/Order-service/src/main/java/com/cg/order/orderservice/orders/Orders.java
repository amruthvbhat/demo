package com.cg.order.orderservice.orders;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.cg.order.orderservice.cart.Items;
import com.cg.order.orderservice.orders.address.Address;
import com.cg.order.orderservice.orders.product.Product;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Document("order")
@Data
@AllArgsConstructor 
@NoArgsConstructor 
@Getter
@Setter
 public class Orders {
	@Id
	private int orderId;
	private LocalDate orderDate;
	private Integer customerId;
	private double amountPaid;
	private String modeOfPayment;
	private String orderStatus;
	private int quantity;
	
	
	private Address address;
	private Product product;
	

}
	


