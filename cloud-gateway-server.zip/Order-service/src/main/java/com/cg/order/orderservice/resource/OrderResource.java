package com.cg.order.orderservice.resource;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.order.orderservice.cart.Cart;
import com.cg.order.orderservice.orders.Orders;
import com.cg.order.orderservice.orders.address.Address;
import com.cg.order.orderservice.orders.address.UserProfile;
import com.cg.order.orderservice.orders.product.Product;
import com.cg.order.orderservice.orders.service.OrderService;



@RestController
@RequestMapping("/order")
public class OrderResource {
	
	@Autowired
	private RestTemplate restTemplate;

	
	@Autowired
	private OrderService orderService;
	
	@GetMapping("/getall_orders")
	public List<Orders> getAllOrders()
	{
		List<Orders> orders = orderService.getAllOrders();
		orders.forEach(order ->
		{
			Product product = restTemplate.getForObject("http://Product-service/product/getById/"+order.getProduct().getProductId(), Product.class);
			order.getProduct().setProductName(product.getProductName());
		});
		return orders;
	}
	
	
	
	@DeleteMapping("/deleteorder/{orderId}")
	public void deleteOrder(@PathVariable("ProductId") int orderId)
	{
		orderService.deleteOrder(orderId);
	}
	
	@GetMapping("/getorderby_custid/{customerId}")
	public List<Orders> getOrderByCustomerId(@PathVariable("customerId") int customerId)
	{
		return orderService.getOrderByCustomerId(customerId);
	}
	
	@PostMapping("/store_address/{orderId}")
	public void storeAddress(@PathVariable("orderId") int orderId,@RequestBody Address address)
	{
		orderService.storeAddress(address,orderId );
	}
	
	@GetMapping("/getAddressBy_CustomerId/{customerId}")
	public List<Address> getAddressByCustomerId(@PathVariable("customerId")int customerId)
	{
		return orderService.getAddressByCustomerId(customerId);
	}
	
	@GetMapping("/getall_address")
	public List<Address> getAllAddress()
	{
		List<Address> address = orderService.getAllAddress();
		address.forEach(eachAddress ->
		{
			UserProfile user = restTemplate.getForObject("http://Profile-service/profile/getByProfileId/"+eachAddress.getCustomerId(), UserProfile.class);
			eachAddress.setFullName(user.getFullName());
			eachAddress.setMobileNumber(user.getMobilenumber().toString());
		});
		return address;
	}
	
	@GetMapping("/getorder_byId/{orderId}")
	public Optional<Orders> getOrderById(@PathVariable("orderId")int orderId)
	{
		return orderService.getOrderById(orderId);
		
	}
	
	@PostMapping("/placeOrder")
	public void placeOrder(@RequestBody Cart cart)
	{
		orderService.placeOrder(cart);
	}
	

}
