package com.capgemini.cartservice;




import static org.mockito.ArgumentMatchers.any;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.internal.matchers.apachecommons.ReflectionEquals;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.unitils.reflectionassert.ReflectionAssert;

import com.capgemini.cartservice.entity.Cart;
import com.capgemini.cartservice.entity.Items;
import com.capgemini.cartservice.repository.CartRepository;
import com.capgemini.cartservice.service.CartService;
import com.capgemini.cartservice.service.CartServiceImpl;


@RunWith(SpringRunner.class)
@DisplayName("cart service test")
class SampleTestApplicationTests {
	
	@InjectMocks
	private CartServiceImpl cartService;

	@Mock
	private CartRepository repository;
	
	@BeforeEach
	void init_mocks()
	{
		MockitoAnnotations.openMocks(this);
	}
	
	@Nested
	class method_getallcarts
	{
		
		@Test
		public void getAllcarts1()
		{
			cartService.getallcarts();
			InOrder inorder=inOrder(repository);
			inorder.verify(repository,times(1)).findAll();
			//when(repository.findAll()).thenReturn(Stream.of(new Cart(555,5000.00, items),new Cart(556,6000.00,items)).collect(Collectors.toList()));
			
			//assertEquals(0,0);
		}
	
	
		@Test
		public void getAllcarts2()
		{
			Items item = new Items(10,"apple",20.0,2);
			List<Items> items= new ArrayList<Items>();
			items.add(item);
			//Cart expected=new Cart(11,2000.00,items);
			when(repository.findAll()).thenReturn(Stream
					.of(new Cart(11,2000.00,items), new Cart(11,2000.00,items)).collect(Collectors.toList()));
			assertEquals(2, cartService.getallcarts().size());
		
		
		}
	}
	

	
	@Nested
	class method_getcartById
	{

		@Test
		void getcartById1()
		{
			cartService.getcartById(100);
			InOrder inOrder=Mockito.inOrder(repository);
			inOrder.verify(repository,times(1)).findById(100);
		}
		
		@Test
		void getcartById2()
		{
			Items item = new Items(10,"apple",20.0,2);
			List<Items> items= new ArrayList<Items>();
			items.add(item);
			
			Cart expected=new Cart(11,2000.00,items);
			
		
			/*when(repository.findAll())
			.thenReturn(Stream.of(new Cart(555,5000.00, items)).collect(Collectors.toList()));
			Cart recievedcart=cartService.getcartById(555);
			equals(recievedcart);*/
			
			when(repository.findByCartId(any(Integer.class))).thenReturn(expected);
			Cart recieved=new Cart(11,2000.00,items);
			cartService.getcartById(11);
			
			assertEquals(expected,recieved);
			ReflectionAssert.assertReflectionEquals(expected,recieved);
			
		}

		
	}
	
	
	@Nested
	class method_addCart
	{
		@Test
		void addCart1()
		{
			Items item = new Items(10,"apple",20.0,2);
			List<Items> items= new ArrayList<Items>();
			Cart cart=new Cart(11,2000.00,items);
			cartService.addCart(cart);
			InOrder inOrder = Mockito.inOrder(repository);
			inOrder.verify(repository,times(1)).save(any(Cart.class));
		}
		
		@Test
		void addCart2()
		{
			Items item = new Items(10,"apple",20.0,2);
			List<Items> items= new ArrayList<Items>();
			items.add(item);
			Cart cart=new Cart(11,2000.00,items);
			cartService.addCart(cart);
			when(repository.findByCartId(11)).thenReturn(cart);
			when(repository.existsById(any(Integer.class))).thenReturn(true);
		}
		
	}
	
	@Nested
	class method_deleteItem
	{
		@Test
		void deleteItem1()
		{
			cartService.getcartById(100);
			InOrder inOrder=Mockito.inOrder(repository);
			inOrder.verify(repository,times(1)).findById(100);
		}
		@Test
		void deleteItem2()
		{
			List<Items> items = new ArrayList<Items>();
			Cart cart=new Cart(11,2000.00,items);
			
			when(repository.findByCartId(any(Integer.class))).thenReturn(cart);
			Items item = new Items(10,"apple",20.0,2);
			
			items.add(item);
			item.getItemId();
			cart.setTotalPrice(cart.getTotalPrice()-(item.getQuantity()*item.getPrice()));
			cart.getListOfItems().remove(item);
			repository.save(cart);
			InOrder inorder=inOrder(repository);
			inorder.verify(repository,times(1)).save(cart);
		}
	}
	
	@Nested
	class method_cartTotal
	{
		
		@Test
		void cartTotal1()
		{
			Items item = new Items(10,"apple",20.0,2);
			List<Items> items= new ArrayList<Items>();
			Double expectedTotalPrice=2000.00;
			Cart cart=new Cart(11,2000.00,items);
			when(repository.findByCartId(any(Integer.class))).thenReturn(cart);
			Double actualTotalPrice= cart.getTotalPrice();
			InOrder inOrder=Mockito.inOrder(repository);
			inOrder.verify(repository,times(0)).findByCartId(11);
		}
		
		
		@Test
		void cartTotal2()
		{
			Items item = new Items(10,"apple",20.0,2);
			List<Items> items= new ArrayList<Items>();
			Double expectedTotalPrice=2000.00;
			Cart cart=new Cart(11,2000.00,items);
			when(repository.findByCartId(any(Integer.class))).thenReturn(cart);
			Double actualTotalPrice= cart.getTotalPrice();
			assertEquals(expectedTotalPrice,actualTotalPrice);
			ReflectionAssert.assertReflectionEquals(expectedTotalPrice, actualTotalPrice);
		
		}
	}
	
	@Nested
	class method_getallItems
	{
		@Test
		void getallItems1()
		{
			Items item = new Items(10,"apple",20.0,2);
			List<Items> items = new ArrayList<Items>();
			Cart cart=new Cart(11,2000.00,items);
			cart.getListOfItems();
			InOrder inorder=inOrder(repository);
			inorder.verify(repository,times(0)).findAll();
			
		}
		
		@Test
		void getallItems2()
		{
			Items item = new Items(10,"apple",20.0,2);
			List<Items> items_expected = new ArrayList<Items>();
			List<Items> items_actual = new ArrayList<Items>();
			items_expected.add(item);
			items_actual.add(item);
			Cart expectedcart=new Cart(11,2000.00,items_expected);
			Cart actualcart=new Cart(11,2000.00,items_actual);
			expectedcart.getListOfItems();
			actualcart.getListOfItems();
			
			when(repository.findByCartId(any(Integer.class))).thenReturn(expectedcart);
			ReflectionAssert.assertReflectionEquals(expectedcart, actualcart);
			
		}
	}
	
	@Nested
	class method_update
	{
		@Test
		void updateCart1()
		{
			
			List<Items> new_items = new ArrayList<Items>();
			Cart cart=new Cart(11,2000.00,new_items);
			
			when(repository.findByCartId(any(Integer.class))).thenReturn(cart);
			Items item = new Items(10,"apple",20.0,2);
			new_items.add(item);
			cart.setListOfItems(new_items);
			cart.setTotalPrice(cart.getTotalPrice()+(item.getPrice()*item.getQuantity()));
			repository.save(cart);
			InOrder inorder=inOrder(repository);
			inorder.verify(repository,times(1)).save(cart);
		}
		
		@Test
		void updateCart2()
		{
			 
			List<Items> items= new ArrayList<Items>();
			Cart new_cart=new Cart(11,2000.00,items);
			Items item = new Items(10,"apple",20.0,2);
			items.add(item);
			List<Items> previous_item_list=new_cart.getListOfItems();
			previous_item_list.add(item);
			new_cart.setListOfItems(previous_item_list);
			when(repository.findByCartId(any(Integer.class))).thenReturn(new_cart);
			new_cart.setTotalPrice(new_cart.getTotalPrice()+(item.getPrice()*item.getQuantity()));
			repository.save(new_cart);
			InOrder inorder=inOrder(repository);
			inorder.verify(repository,times(1)).save(new_cart);
		
		}
	}
	
	


}