package com.capgemini.discoveryserverservice;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryserverServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
