package com.eshoppingzone.profile.UserProfileService.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eshoppingzone.profile.UserProfileService.pojo.UserProfile;
import com.eshoppingzone.profile.UserProfileService.service.ProfileService;

@RestController
@RequestMapping("/profile")
public class ProfileResource {
	
	@Autowired
	private ProfileService service;
	
	@GetMapping("/getall")
	public List<UserProfile> getAllProfiles()
	{
		return service.getAllProfiles();
	}
	
	@GetMapping("/getid/{id}")
	public UserProfile getByProfileId(@PathVariable("id") Integer profileId)
	{
		return service.getByProfileId(profileId);
	}
	
	@DeleteMapping("/deleteprofile/{ProfileId}")
	public void deleteProfile(Integer profileId)
	{
		service.deleteProfile(profileId);
		
	}
	
	@GetMapping("/getbymobile/{mobileNumber}")
	public UserProfile findByMobileNo(@PathVariable("mobileNumber") Long mobileNumber)
	{
		return service.findByMobileNo(mobileNumber);
	}
	
	@GetMapping("/getbyname/{name}")
	public UserProfile getByUserName(@PathVariable("name")String fullName)
	{
		return service.getByUserName(fullName);
	}
	
	@PostMapping("/customerProfile")
	public UserProfile addNewCustomerProfile(@RequestBody UserProfile userprofile)
	{
		return service.addNewCustomerProfile(userprofile);
		
	}
	
	@PostMapping("/merchant")
	public void addNewMerchantProfile(@RequestBody UserProfile userprofile)
	{
		service.addNewMerchantProfile(userprofile);
	}

	@PostMapping("/delivery")
	public void addNewdeliveryProfile(@RequestBody UserProfile Userprofile)
	{
		service.addNewdeliveryProfile(Userprofile);
	}
	
	@PutMapping("/updateprofile")
	public void updateProfile(@RequestBody UserProfile userprofile)
	{
		service.updateProfile(userprofile);
	}
}
