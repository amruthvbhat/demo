package com.eshoppingzone.profile.UserProfileService.pojo;

public interface Role {
	public static final String Customer = "CUSTOMER";
	public static final String Merchant = "MERCHANT";
	public static final String DeliveryAgent = "DELIVERYAGENT";

}
