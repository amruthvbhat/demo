package com.eshoppingzone.profile.UserProfileService.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eshoppingzone.profile.UserProfileService.pojo.UserProfile;
import com.eshoppingzone.profile.UserProfileService.repository.ProfileRepository;



@Service
public class ProfileServiceImpl implements ProfileService{
	
	@Autowired
	private ProfileRepository repository;

	@Override
	public UserProfile addNewCustomerProfile(UserProfile Userprofile) {
		// TODO Auto-generated method stub  "learn this- related below two methods"
		return repository.save(Userprofile);
	}

	@Override
	public void addNewMerchantProfile(UserProfile Userprofile) {
		// TODO Auto-generated method stub
		repository.save(Userprofile);
	}

	@Override
	public void addNewdeliveryProfile(UserProfile Userprofile) {
		// TODO Auto-generated method stub
		repository.save(Userprofile);
	}

	@Override
	public List<UserProfile> getAllProfiles() {
		// TODO Auto-generated method stub "done"
		return repository.findAll();
	}

	@Override
	public UserProfile getByProfileId(Integer profileId) {
		// TODO Auto-generated method stub "done"
		return repository.findById(profileId).orElse(null);
	}

	@Override
	public void updateProfile(UserProfile userprofile) {
		// TODO Auto-generated method stub
		UserProfile newuser= repository.findById(userprofile.getProfileId()).orElse(null);
		if(newuser!=null)
		{
			newuser.setAbout(userprofile.getAbout());
			newuser.setDateOfBirth(userprofile.getDateOfBirth());
			newuser.setEmailId(userprofile.getEmailId());
			newuser.setFullName(userprofile.getFullName());
			newuser.setGender(userprofile.getGender());
			newuser.setImage(userprofile.getImage());
			newuser.setMobileNumber(userprofile.getMobileNumber());
			newuser.setPassword(userprofile.getPassword());
			newuser.setAddresses(userprofile.getAddresses());
			newuser.setRole(userprofile.getRole());
			
			repository.save(newuser);
		}
		else
		{
			repository.save(userprofile);
		}
	}

	@Override
	public void deleteProfile(Integer profileId) {
		// TODO Auto-generated method stub "done"
		UserProfile user= repository.findById(profileId).orElse(null);
		repository.delete(user);
		
	}

	@Override
	public UserProfile findByMobileNo(Long mobileNumber) {
		// TODO Auto-generated method stub "done"
		return repository.findAllByMobileNumber(mobileNumber);
	}

	@Override
	public UserProfile getByUserName(String fullName) {
		// TODO Auto-generated method stub "done"
		return repository.findByfullName(fullName);
	}
	
	

}
