package com.eshoppingzone.profile.UserProfileService.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.eshoppingzone.profile.UserProfileService.pojo.UserProfile;

@Service
public interface ProfileService {
	
	UserProfile addNewCustomerProfile(UserProfile Userprofile);//1
	void addNewMerchantProfile(UserProfile Userprofile);//2
	void addNewdeliveryProfile(UserProfile Userprofile);//3
	List<UserProfile> getAllProfiles();//4
	UserProfile getByProfileId(Integer profileId);//5
	void updateProfile(UserProfile userprofile);//6
	void deleteProfile(Integer profileId);//7
	UserProfile findByMobileNo(Long mobileNumber);//8
	UserProfile getByUserName(String fullName);//9
	

}
