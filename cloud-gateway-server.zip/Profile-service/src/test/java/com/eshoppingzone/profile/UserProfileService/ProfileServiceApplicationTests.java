package com.eshoppingzone.profile.UserProfileService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.inOrder;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.OngoingStubbing;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.unitils.reflectionassert.ReflectionAssert;


import com.eshoppingzone.profile.UserProfileService.pojo.Address;
import com.eshoppingzone.profile.UserProfileService.pojo.UserProfile;
import com.eshoppingzone.profile.UserProfileService.repository.ProfileRepository;
import com.eshoppingzone.profile.UserProfileService.service.ProfileService;
import com.eshoppingzone.profile.UserProfileService.service.ProfileServiceImpl;

@ExtendWith(MockitoExtension.class)
@DisplayName("Testing ProfileServiceImpl")
class ProfileServiceApplicationTests {

	@InjectMocks
	ProfileServiceImpl profileService;
	
	@Mock
	ProfileRepository profileRepository;
	
	@BeforeEach
	void init_mocks() {
		MockitoAnnotations.openMocks(this);
	}


	@Nested
	@DisplayName("addNewCustomerProfile")
	class addNewCustomerProfile_Method{
		
		@Test
		public void addNewCustomerProfile1()
		{
			Address address = new Address(44,"keb-street","colony","banglore","kar",560085);
			List<Address> Addresses=new ArrayList<Address>();
			Addresses.add(address);
			UserProfile userprofile=new UserProfile(10, null, "amruth", null, null, null, null, null, null, null, Addresses);
			profileService.addNewCustomerProfile(userprofile);
			
			InOrder inorder=inOrder(profileRepository);
			inorder.verify(profileRepository,times(1)).save(userprofile);
		}
		
		@Test
		public void addNewCustomerProfile2()
		{
			Address address = new Address(44,"keb-street","colony","banglore","kar",560085);
			List<Address> Addresses=new ArrayList<Address>();
			Addresses.add(address);
			UserProfile userprofile=new UserProfile(10, null,  "amruth", null, null, null, null, null, null, null, Addresses);
			profileService.addNewCustomerProfile(userprofile);
			profileRepository.save(userprofile);

		}
	}
	
	@Nested
	@DisplayName("addNewMerchantProfile")
	class addNewMerchantProfile_Method{
		
		@Test
		public void addNewMerchantProfile1()
		{
			Address address = new Address(44,"keb-street","colony","banglore","kar",560085);
			List<Address> Addresses=new ArrayList<Address>();
			Addresses.add(address);
			UserProfile userprofile=new UserProfile(10, null, "amruth", null, null, null, null, null, null, null, Addresses);
			profileService.addNewCustomerProfile(userprofile);
			
			InOrder inorder=inOrder(profileRepository);
			inorder.verify(profileRepository,times(1)).save(userprofile);
		}
		
		@Test
		public void addNewMerchantProfile2()
		{
			Address address = new Address(44,"keb-street","colony","banglore","kar",560085);
			List<Address> Addresses=new ArrayList<Address>();
			Addresses.add(address);
			UserProfile userprofile=new UserProfile(10, null,  "amruth", null, null, null, null, null, null, null, Addresses);
			profileService.addNewCustomerProfile(userprofile);
			profileRepository.save(userprofile);

		}
	}
	
	@Nested
	@DisplayName("getAllProfiles")
	class getAllProfiles_Method{
		
		@Test
		public void getAllProfiles1()
		{
			profileService.getAllProfiles();
			InOrder inorder=inOrder(profileRepository);
			inorder.verify(profileRepository,times(1)).findAll();
		}
		
		@Test
		public void getAllProfiles2()
		{
			Address address = new Address(44,"keb-street","colony","banglore","kar",560085);
			List<Address> Addresses=new ArrayList<Address>();
			Addresses.add(address);
			//UserProfile userprofile1=new UserProfile(10,"amruth","dp.png", "amruth@gmail.com", null, null, null, "male","customer", "password", Addresses);
			when(profileRepository.findAll()).thenReturn(Stream
					.of(new UserProfile(10,"amruth","dp.png", "amruth@gmail.com", null, null, null, "male","customer", "password", Addresses)).collect(Collectors.toList()));
			assertEquals(1, profileService.getAllProfiles().size());
		}
		
	}
	
	@Nested
	@DisplayName("getByProfileId")
	class getByProfileId_Method{
		
		@Test
		public void getByProfileId1()
		{
			profileService.getByProfileId(100);
			InOrder inOrder=Mockito.inOrder(profileRepository);
			inOrder.verify(profileRepository,times(1)).findById(100);
		}
		
		@Test
		public void getByProfileId2()
		{
			Address address = new Address(44,"keb-street","colony","banglore","kar",560085);
			List<Address> Addresses=new ArrayList<Address>();
			Addresses.add(address);
			UserProfile actual_userprofile=new UserProfile(10,"amruth","dp.png", "amruth@gmail.com", null, null, null, "male","customer", "password", Addresses);
			profileService.addNewCustomerProfile(actual_userprofile);
			profileRepository.save(actual_userprofile);
			//when(profileRepository.findByProfileId(10)).thenReturn(actual_userprofile);
			UserProfile expected_userprofile=new UserProfile(10,"amruth","dp.png", "amruth@gmail.com", null, null, null, "male","customer", "password", Addresses);
			assertEquals(expected_userprofile,actual_userprofile);
			ReflectionAssert.assertReflectionEquals(expected_userprofile,actual_userprofile);
		}
		
	}
	
	
	@Nested
	@DisplayName("findByMobileNo")
	class findByMobileNo_Method{
		
		@Test
		public void findByMobileNo1()
		{
			Long mobilenumber=82174L;
			profileService.findByMobileNo(mobilenumber);
			InOrder inOrder=Mockito.inOrder(profileRepository);
			inOrder.verify(profileRepository,times(1)).findAllByMobileNumber(82174L);
		}
		
		@Test
		public void findByMobileNo2()
		{
			Long mobilenumber=82174L;
			Address address = new Address(44,"keb-street","colony","banglore","kar",560085);
			List<Address> Addresses=new ArrayList<Address>();
			Addresses.add(address);
			UserProfile actual_userprofile=new UserProfile(10,"amruth","dp.png", "amruth@gmail.com", mobilenumber, null, null, "male","customer", "password", Addresses);
			profileService.findByMobileNo(mobilenumber);
			//when(profileRepository.findAllByMobileNumber(mobilenumber)).thenReturn(actual_userprofile);
			InOrder inOrder=Mockito.inOrder(profileRepository);
			inOrder.verify(profileRepository,times(1)).findAllByMobileNumber(82174L);
		}
	
	
	}
	
	@Nested
	@DisplayName("getByUserName")
	class getByUserName_Method{
		
		@Test
		public void getByUserName1()
		{
			String fullName="arun";
			profileService.getByUserName(fullName);
			InOrder inOrder=Mockito.inOrder(profileRepository);
			inOrder.verify(profileRepository,times(1)).findByfullName(fullName);
		}
		
		@Test
		public void getByUserName2()
		{
			Address address = new Address(44,"keb-street","colony","banglore","kar",560085);
			List<Address> Addresses=new ArrayList<Address>();
			Addresses.add(address);
			UserProfile actual_userprofile=new UserProfile(10,"amruth","dp.png", "amruth@gmail.com", 82174L, null, null, "male","customer", "password", Addresses);
			profileService.getByUserName("amruth");
			InOrder inOrder=Mockito.inOrder(profileRepository);
			inOrder.verify(profileRepository,times(1)).findByfullName("amruth");
		}
	}
	
	
	@Nested
	@DisplayName("deleteProfile")
	class deleteProfile_Method{
		
		@Test
		public void deleteProfile1()
		{
			
			profileService.getByProfileId(10);
			InOrder inOrder=Mockito.inOrder(profileRepository);
			inOrder.verify(profileRepository,times(1)).findById(10);
			
		}
		@Test
		public void deleteProfile2()
		{
			Address address = new Address(44,"keb-street","colony","banglore","kar",560085);
			List<Address> Addresses=new ArrayList<Address>();
			Addresses.add(address);
			UserProfile actual_userprofile=new UserProfile(10,"amruth","dp.png", "amruth@gmail.com", 82174L, null, null, "male","customer", "password", Addresses);
			profileRepository.delete(actual_userprofile);
			InOrder inOrder=Mockito.inOrder(profileRepository);
			inOrder.verify(profileRepository,times(1)).delete(actual_userprofile);
		}
	}
	
	
	
	@Nested
	@DisplayName("updateProfile")
	class updateProfile_Method{
		
		@Test
		public void updateProfile1()
		{	
			Address address = new Address(44,"keb-street","colony","banglore","kar",560085);
			List<Address> Addresses=new ArrayList<Address>();
			Addresses.add(address);
			UserProfile userprofile=new UserProfile(10,"amruth","dp.png", "amruth@gmail.com", 82174L, null, null, "male","customer", "password", Addresses);
			
			profileRepository.save(userprofile);
			InOrder inorder=inOrder(profileRepository);
			inorder.verify(profileRepository,times(1)).save(userprofile);
			
		}
		
		@Test
		public void updateProfile2()//new user with null data
		{	
			Address address = new Address(44,"keb-street","colony","banglore","kar",560085);
			List<Address> Addresses=new ArrayList<Address>();
			Addresses.add(address);
			UserProfile userprofile=new UserProfile(10,"amruth","dp.png", "amruth@gmail.com", 82174L, null, null, "male","customer", "password", Addresses);
			UserProfile newuser=new UserProfile();
			newuser.setAbout(userprofile.getAbout());
			newuser.setDateOfBirth(userprofile.getDateOfBirth());
			newuser.setEmailId(userprofile.getEmailId());
			newuser.setFullName(userprofile.getFullName());
			newuser.setGender(userprofile.getGender());
			newuser.setImage(userprofile.getImage());
			newuser.setMobileNumber(userprofile.getMobileNumber());
			newuser.setPassword(userprofile.getPassword());
			newuser.setAddresses(userprofile.getAddresses());
			newuser.setRole(userprofile.getRole());
			profileRepository.save(newuser);
			
			InOrder inorder=inOrder(profileRepository);
			inorder.verify(profileRepository,times(1)).save(newuser);
		}
		@Test
		public void updateProfile3()//new user with data
		{	
			Address address = new Address(44,"keb-street","colony","banglore","kar",560085);
			List<Address> Addresses=new ArrayList<Address>();
			Addresses.add(address);
			UserProfile userprofile=new UserProfile(10,"amruth","dp.png", "amruth@gmail.com", 82174L, null, null, "male","customer", "password", Addresses);
			profileRepository.findByProfileId(10);
			profileRepository.save(userprofile);
			
			InOrder inorder=inOrder(profileRepository);
			inorder.verify(profileRepository,times(1)).save(userprofile);
			
			
			
			///InOrder inorder=inOrder(profileRepository);
			//inorder.verify(profileRepository,times(1)).save(newuser);
		}
	}

}
