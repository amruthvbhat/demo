package com.capgemini.cloudgatewayserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudGatewayServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
